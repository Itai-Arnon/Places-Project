package com.project.itai.FindAPlace.fragments;

import com.project.itai.FindAPlace.beans.Place;
import com.project.itai.FindAPlace.beans.Place;

public interface IUserFavAction {

      void deleteAllFavorites();
}

